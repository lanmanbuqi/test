<template>
	<div>
		<h2>购物车</h2>
	</div>
</template>

<script>
</script>

<style>
</style>
