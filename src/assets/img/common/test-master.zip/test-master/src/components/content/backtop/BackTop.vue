<template>
    <div class="back-top">
			<img src="~assets/img/common/backtop.svg">
		</div>
</template>

<script>
    export default {
        name: "BackTop"
    }
</script>

<style scoped>
	.back-top{
		position: fixed;
		right: 10px;
		bottom: 50px;
	}
	.back-top img{
		width: 43px;
		height: 43px;
	}
</style>
